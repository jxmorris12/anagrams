name = "english-anagrams"

from anagrams import anagrams
