outfile = 'anagrams.bin'

import nltk
words = nltk.corpus.words.words()
